ar_camera = "AR_Camera_"
camera_parent = "Camera_Motion_"
cam_col = "Camera"

ar_face = "AR_Face_"
face_parent = "Face_Motion_"
head_controller = "cgt_HeadController"
face_col = "Face"
face_empty_col = "Face_Empties"

ar_reference = "AR_Reference_"
ref_col = "Reference"

ar_point_cloud = "AR_Point_"
pc_col = "Cloud"
